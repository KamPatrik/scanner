"""
Epson V300 Film Scanner Application
A modern, clean interface for scanning analog film
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image, ImageTk, ImageOps, ImageFilter
import os
from datetime import datetime
import threading
import numpy as np

try:
    import twain
    TWAIN_AVAILABLE = True
except ImportError:
    TWAIN_AVAILABLE = False


class FilmScannerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Film Scanner - Epson V300")
        self.root.geometry("1200x800")
        self.root.configure(bg='#2b2b2b')
        
        # Scanner variables
        self.source_manager = None
        self.scanner = None
        self.preview_image = None
        self.scanned_images = []
        
        # Settings
        self.resolution = tk.IntVar(value=2400)
        self.color_mode = tk.StringVar(value="Color")
        self.file_format = tk.StringVar(value="TIFF")
        self.output_dir = tk.StringVar(value=os.path.join(os.path.expanduser("~"), "Desktop", "Scans"))
        self.auto_increment = tk.BooleanVar(value=True)
        self.auto_detect = tk.BooleanVar(value=True)
        self.scan_counter = 1
        
        self.setup_ui()
        self.initialize_scanner()
    
    def setup_ui(self):
        """Create the user interface"""
        # Modern color scheme
        bg_color = '#2b2b2b'
        fg_color = '#ffffff'
        accent_color = '#0078d4'
        panel_color = '#3c3c3c'
        
        # Style configuration
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('TFrame', background=bg_color)
        style.configure('TLabel', background=bg_color, foreground=fg_color, font=('Segoe UI', 10))
        style.configure('TButton', font=('Segoe UI', 10), padding=6)
        style.configure('Accent.TButton', background=accent_color, foreground='white', font=('Segoe UI', 11, 'bold'))
        
        # Main container
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        
        # Left panel - Controls
        left_panel = tk.Frame(main_frame, bg=panel_color, width=350)
        left_panel.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), padx=(0, 10))
        left_panel.grid_propagate(False)
        
        # Title
        title_label = tk.Label(left_panel, text="Film Scanner", font=('Segoe UI', 18, 'bold'),
                               bg=panel_color, fg=fg_color)
        title_label.pack(pady=20)
        
        # Scanner Status
        status_frame = tk.LabelFrame(left_panel, text="Scanner Status", bg=panel_color, fg=fg_color,
                                     font=('Segoe UI', 10, 'bold'), padx=10, pady=10)
        status_frame.pack(fill=tk.X, padx=10, pady=10)
        
        self.status_label = tk.Label(status_frame, text="Initializing...", bg=panel_color, fg='#ffa500',
                                     font=('Segoe UI', 9))
        self.status_label.pack()
        
        # Scan Settings
        settings_frame = tk.LabelFrame(left_panel, text="Scan Settings", bg=panel_color, fg=fg_color,
                                       font=('Segoe UI', 10, 'bold'), padx=10, pady=10)
        settings_frame.pack(fill=tk.X, padx=10, pady=10)
        
        # Resolution
        tk.Label(settings_frame, text="Resolution (DPI):", bg=panel_color, fg=fg_color).grid(row=0, column=0, sticky=tk.W, pady=5)
        resolution_combo = ttk.Combobox(settings_frame, textvariable=self.resolution, width=15,
                                       values=[1200, 2400, 3200, 4800, 6400])
        resolution_combo.grid(row=0, column=1, pady=5)
        
        # Color Mode
        tk.Label(settings_frame, text="Color Mode:", bg=panel_color, fg=fg_color).grid(row=1, column=0, sticky=tk.W, pady=5)
        color_combo = ttk.Combobox(settings_frame, textvariable=self.color_mode, width=15,
                                   values=["Color", "Grayscale", "Black & White"])
        color_combo.grid(row=1, column=1, pady=5)
        
        # File Format
        tk.Label(settings_frame, text="File Format:", bg=panel_color, fg=fg_color).grid(row=2, column=0, sticky=tk.W, pady=5)
        format_combo = ttk.Combobox(settings_frame, textvariable=self.file_format, width=15,
                                    values=["TIFF", "PNG", "JPEG"])
        format_combo.grid(row=2, column=1, pady=5)
        
        # Output Directory
        output_frame = tk.LabelFrame(left_panel, text="Output", bg=panel_color, fg=fg_color,
                                     font=('Segoe UI', 10, 'bold'), padx=10, pady=10)
        output_frame.pack(fill=tk.X, padx=10, pady=10)
        
        tk.Label(output_frame, text="Save to:", bg=panel_color, fg=fg_color).pack(anchor=tk.W)
        
        dir_frame = tk.Frame(output_frame, bg=panel_color)
        dir_frame.pack(fill=tk.X, pady=5)
        
        self.dir_label = tk.Label(dir_frame, text=self.output_dir.get()[:30] + "...", 
                                  bg=panel_color, fg='#aaaaaa', anchor=tk.W)
        self.dir_label.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        browse_btn = ttk.Button(dir_frame, text="Browse", command=self.browse_directory)
        browse_btn.pack(side=tk.RIGHT)
        
        tk.Checkbutton(output_frame, text="Auto-increment filenames", variable=self.auto_increment,
                      bg=panel_color, fg=fg_color, selectcolor=panel_color,
                      activebackground=panel_color, activeforeground=fg_color).pack(anchor=tk.W, pady=5)
        
        tk.Checkbutton(output_frame, text="Auto-detect film frames", variable=self.auto_detect,
                      bg=panel_color, fg=fg_color, selectcolor=panel_color,
                      activebackground=panel_color, activeforeground=fg_color).pack(anchor=tk.W, pady=2)
        
        # Action Buttons
        button_frame = tk.Frame(left_panel, bg=panel_color)
        button_frame.pack(fill=tk.X, padx=10, pady=20)
        
        self.preview_btn = tk.Button(button_frame, text="Preview", command=self.preview_scan,
                                     bg='#555555', fg='white', font=('Segoe UI', 11),
                                     relief=tk.FLAT, cursor='hand2', padx=20, pady=10)
        self.preview_btn.pack(fill=tk.X, pady=5)
        
        self.scan_btn = tk.Button(button_frame, text="Scan", command=self.start_scan,
                                  bg=accent_color, fg='white', font=('Segoe UI', 12, 'bold'),
                                  relief=tk.FLAT, cursor='hand2', padx=20, pady=12)
        self.scan_btn.pack(fill=tk.X, pady=5)
        
        self.batch_btn = tk.Button(button_frame, text="Batch Scan", command=self.batch_scan,
                                   bg='#0d6efd', fg='white', font=('Segoe UI', 11),
                                   relief=tk.FLAT, cursor='hand2', padx=20, pady=10)
        self.batch_btn.pack(fill=tk.X, pady=5)
        
        # Statistics
        stats_frame = tk.LabelFrame(left_panel, text="Session Info", bg=panel_color, fg=fg_color,
                                    font=('Segoe UI', 10, 'bold'), padx=10, pady=10)
        stats_frame.pack(fill=tk.X, padx=10, pady=10)
        
        self.stats_label = tk.Label(stats_frame, text="Scans completed: 0", bg=panel_color, fg=fg_color)
        self.stats_label.pack()
        
        # Right panel - Preview
        right_panel = tk.Frame(main_frame, bg=panel_color)
        right_panel.grid(row=0, column=1, sticky=(tk.W, tk.E, tk.N, tk.S))
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(0, weight=1)
        
        preview_label = tk.Label(right_panel, text="Preview", font=('Segoe UI', 14, 'bold'),
                                bg=panel_color, fg=fg_color)
        preview_label.pack(pady=10)
        
        # Preview canvas
        self.preview_canvas = tk.Canvas(right_panel, bg='#1a1a1a', highlightthickness=0)
        self.preview_canvas.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        self.preview_text = self.preview_canvas.create_text(
            400, 300, text="No preview available\nClick 'Preview' to see scan preview",
            fill='#666666', font=('Segoe UI', 12), justify=tk.CENTER
        )
    
    def initialize_scanner(self):
        """Initialize connection to scanner"""
        if not TWAIN_AVAILABLE:
            self.status_label.config(text="TWAIN not available - Install python-twain", fg='#ff4444')
            messagebox.showwarning("TWAIN Not Available",
                                 "Python TWAIN library not installed.\n\n"
                                 "To use this scanner application, please install:\n"
                                 "pip install pytwain\n\n"
                                 "For now, you can test the interface in demo mode.")
            self.scan_btn.config(state=tk.DISABLED)
            self.preview_btn.config(state=tk.DISABLED)
            self.batch_btn.config(state=tk.DISABLED)
            return
        
        try:
            self.source_manager = twain.SourceManager(0)
            scanner_name = self.source_manager.GetSourceList()[0]
            self.scanner = self.source_manager.OpenSource(scanner_name)
            self.status_label.config(text=f"Connected: {scanner_name}", fg='#00ff00')
        except Exception as e:
            self.status_label.config(text=f"Error: {str(e)}", fg='#ff4444')
            messagebox.showerror("Scanner Error", f"Could not connect to scanner:\n{str(e)}")
    
    def browse_directory(self):
        """Browse for output directory"""
        directory = filedialog.askdirectory(initialdir=self.output_dir.get())
        if directory:
            self.output_dir.set(directory)
            self.dir_label.config(text=directory[:30] + "...")
    
    def preview_scan(self):
        """Show preview of scan"""
        if not TWAIN_AVAILABLE or not self.scanner:
            messagebox.showinfo("Demo Mode", "Preview would show here when scanner is connected")
            return
        
        self.status_label.config(text="Generating preview...", fg='#ffa500')
        threading.Thread(target=self._do_preview, daemon=True).start()
    
    def _do_preview(self):
        """Perform preview scan in background thread"""
        try:
            # Set up scanner for preview (lower resolution)
            self.scanner.SetCapability(twain.ICAP_XRESOLUTION, twain.TWTY_FIX32, 150)
            self.scanner.SetCapability(twain.ICAP_YRESOLUTION, twain.TWTY_FIX32, 150)
            
            # Request scan
            self.scanner.RequestAcquire(0, 0)
            image = self.scanner.XferImageNatively()[0]
            
            # Convert and display
            self.preview_image = Image.open(image)
            self.display_preview(self.preview_image)
            
            self.root.after(0, lambda: self.status_label.config(text="Preview ready", fg='#00ff00'))
        except Exception as e:
            self.root.after(0, lambda: self.status_label.config(text=f"Preview failed: {str(e)}", fg='#ff4444'))
    
    def display_preview(self, image):
        """Display preview image on canvas"""
        # Resize to fit canvas
        canvas_width = self.preview_canvas.winfo_width()
        canvas_height = self.preview_canvas.winfo_height()
        
        if canvas_width < 100:  # Canvas not initialized yet
            canvas_width = 800
            canvas_height = 600
        
        # Calculate scaling
        img_ratio = image.width / image.height
        canvas_ratio = canvas_width / canvas_height
        
        if img_ratio > canvas_ratio:
            new_width = canvas_width - 40
            new_height = int(new_width / img_ratio)
        else:
            new_height = canvas_height - 40
            new_width = int(new_height * img_ratio)
        
        resized = image.resize((new_width, new_height), Image.Resampling.LANCZOS)
        photo = ImageTk.PhotoImage(resized)
        
        # Display on canvas
        self.preview_canvas.delete("all")
        self.preview_canvas.create_image(canvas_width // 2, canvas_height // 2, image=photo)
        self.preview_canvas.image = photo  # Keep reference
    
    def start_scan(self):
        """Start a single scan"""
        if not TWAIN_AVAILABLE or not self.scanner:
            messagebox.showinfo("Demo Mode", "Scanning would occur here when scanner is connected")
            return
        
        self.status_label.config(text="Scanning...", fg='#ffa500')
        self.scan_btn.config(state=tk.DISABLED)
        threading.Thread(target=self._do_scan, daemon=True).start()
    
    def _do_scan(self):
        """Perform scan in background thread"""
        try:
            # Configure scanner
            resolution = self.resolution.get()
            self.scanner.SetCapability(twain.ICAP_XRESOLUTION, twain.TWTY_FIX32, resolution)
            self.scanner.SetCapability(twain.ICAP_YRESOLUTION, twain.TWTY_FIX32, resolution)
            
            # Set color mode
            if self.color_mode.get() == "Color":
                pixel_type = twain.TWPT_RGB
            elif self.color_mode.get() == "Grayscale":
                pixel_type = twain.TWPT_GRAY
            else:
                pixel_type = twain.TWPT_BW
            
            self.scanner.SetCapability(twain.ICAP_PIXELTYPE, twain.TWTY_UINT16, pixel_type)
            
            # Acquire image
            self.scanner.RequestAcquire(0, 0)
            image_data = self.scanner.XferImageNatively()[0]
            image = Image.open(image_data)
            
            # Auto-detect film frames if enabled
            if self.auto_detect.get():
                frames = self.detect_film_frames(image)
                if frames:
                    self.root.after(0, lambda: self.status_label.config(
                        text=f"Detected {len(frames)} frames, saving...", fg='#ffa500'))
                    self.save_detected_frames(frames)
                    return
            
            # Save single image (no auto-detect or no frames found)
            filename = self.generate_filename()
            filepath = os.path.join(self.output_dir.get(), filename)
            
            os.makedirs(self.output_dir.get(), exist_ok=True)
            
            if self.file_format.get() == "TIFF":
                image.save(filepath, "TIFF", compression="tiff_lzw")
            elif self.file_format.get() == "PNG":
                image.save(filepath, "PNG")
            else:
                image.save(filepath, "JPEG", quality=95)
            
            self.scanned_images.append(filepath)
            
            self.root.after(0, self.scan_complete, filepath)
            
        except Exception as e:
            self.root.after(0, lambda: self.scan_failed(str(e)))
    
    def generate_filename(self):
        """Generate filename for scanned image"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        ext_map = {"TIFF": "tif", "PNG": "png", "JPEG": "jpg"}
        ext = ext_map[self.file_format.get()]
        
        if self.auto_increment.get():
            filename = f"film_scan_{self.scan_counter:04d}.{ext}"
            self.scan_counter += 1
        else:
            filename = f"film_scan_{timestamp}.{ext}"
        
        return filename
    
    def detect_film_frames(self, image):
        """Detect individual film frames in a scanned image"""
        try:
            # Convert to grayscale for analysis
            gray = ImageOps.grayscale(image)
            
            # Convert to numpy array
            img_array = np.array(gray)
            
            # Find bright areas (film frames are typically brighter than background)
            # Threshold to create binary image
            threshold = np.mean(img_array) + np.std(img_array) * 0.5
            binary = img_array > threshold
            
            # Find contiguous regions (simple row/column analysis)
            frames = []
            min_frame_size = 1000  # Minimum pixels for a frame
            
            # Detect columns with content
            col_sums = np.sum(binary, axis=0)
            col_threshold = img_array.shape[0] * 0.1  # At least 10% of column height
            
            in_frame = False
            frame_start = 0
            
            for i, col_sum in enumerate(col_sums):
                if col_sum > col_threshold and not in_frame:
                    frame_start = i
                    in_frame = True
                elif col_sum <= col_threshold and in_frame:
                    # Found end of frame
                    frame_width = i - frame_start
                    if frame_width > 100:  # Minimum width
                        # Now find top and bottom of frame
                        frame_region = binary[:, frame_start:i]
                        row_sums = np.sum(frame_region, axis=1)
                        row_threshold = frame_width * 0.1
                        
                        rows_with_content = np.where(row_sums > row_threshold)[0]
                        if len(rows_with_content) > 100:  # Minimum height
                            top = rows_with_content[0]
                            bottom = rows_with_content[-1]
                            
                            # Add some padding
                            padding = 10
                            left = max(0, frame_start - padding)
                            right = min(image.width, i + padding)
                            top = max(0, top - padding)
                            bottom = min(image.height, bottom + padding)
                            
                            frames.append((left, top, right, bottom))
                    
                    in_frame = False
            
            return frames
            
        except Exception as e:
            print(f"Error detecting frames: {e}")
            return []
    
    def save_detected_frames(self, frames):
        """Save individual detected frames"""
        try:
            saved_files = []
            
            for i, (left, top, right, bottom) in enumerate(frames):
                # Crop the frame
                frame_img = self.preview_image.crop((left, top, right, bottom)) if self.preview_image else None
                
                if frame_img:
                    filename = self.generate_filename()
                    filepath = os.path.join(self.output_dir.get(), filename)
                    
                    os.makedirs(self.output_dir.get(), exist_ok=True)
                    
                    if self.file_format.get() == "TIFF":
                        frame_img.save(filepath, "TIFF", compression="tiff_lzw")
                    elif self.file_format.get() == "PNG":
                        frame_img.save(filepath, "PNG")
                    else:
                        frame_img.save(filepath, "JPEG", quality=95)
                    
                    saved_files.append(filepath)
                    self.scanned_images.append(filepath)
            
            if saved_files:
                self.root.after(0, lambda: self.multi_scan_complete(saved_files))
            else:
                self.root.after(0, lambda: self.scan_failed("No frames detected"))
                
        except Exception as e:
            self.root.after(0, lambda: self.scan_failed(f"Error saving frames: {str(e)}"))
    
    def multi_scan_complete(self, filepaths):
        """Handle successful multi-frame scan"""
        self.status_label.config(text=f"Saved {len(filepaths)} frames!", fg='#00ff00')
        self.scan_btn.config(state=tk.NORMAL)
        self.stats_label.config(text=f"Scans completed: {len(self.scanned_images)}")
        files_list = "\n".join([os.path.basename(f) for f in filepaths])
        messagebox.showinfo("Scan Complete", f"Saved {len(filepaths)} frames:\n{files_list}")
    
    def scan_complete(self, filepath):
        """Handle successful scan"""
        self.status_label.config(text="Scan complete!", fg='#00ff00')
        self.scan_btn.config(state=tk.NORMAL)
        self.stats_label.config(text=f"Scans completed: {len(self.scanned_images)}")
        messagebox.showinfo("Scan Complete", f"Image saved to:\n{filepath}")
    
    def scan_failed(self, error):
        """Handle scan failure"""
        self.status_label.config(text=f"Scan failed: {error}", fg='#ff4444')
        self.scan_btn.config(state=tk.NORMAL)
        messagebox.showerror("Scan Failed", f"Error during scanning:\n{error}")
    
    def batch_scan(self):
        """Start batch scanning mode"""
        if not TWAIN_AVAILABLE or not self.scanner:
            messagebox.showinfo("Demo Mode", "Batch scanning would occur here when scanner is connected")
            return
        
        count = tk.simpledialog.askinteger("Batch Scan", "How many images to scan?", 
                                          initialvalue=5, minvalue=1, maxvalue=100)
        if count:
            self.status_label.config(text=f"Batch scanning {count} images...", fg='#ffa500')
            threading.Thread(target=self._do_batch_scan, args=(count,), daemon=True).start()
    
    def _do_batch_scan(self, count):
        """Perform batch scan"""
        for i in range(count):
            self.root.after(0, lambda i=i: self.status_label.config(
                text=f"Scanning {i+1} of {count}...", fg='#ffa500'))
            self._do_scan()
            if i < count - 1:
                self.root.after(0, lambda: messagebox.showinfo("Ready", "Load next film and click OK"))
        
        self.root.after(0, lambda: self.status_label.config(text="Batch scan complete!", fg='#00ff00'))


def main():
    root = tk.Tk()
    app = FilmScannerApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
