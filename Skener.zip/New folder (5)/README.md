# Film Scanner for Epson V300

A modern, fast, and user-friendly application for scanning analog film with the Epson V300 scanner.

## Features

- **Clean, Modern Interface** - Dark theme, intuitive controls
- **High-Resolution Scanning** - Up to 6400 DPI for film
- **Quick Preview** - See your scan before committing
- **Batch Scanning** - Scan multiple frames efficiently
- **Multiple Formats** - Export as TIFF, PNG, or JPEG
- **Auto-Naming** - Automatic file naming with counter
- **Color Control** - Color, grayscale, or B&W modes
- **Fast & Responsive** - No lag or freezing

## Installation

### Step 1: Install Python
If you don't have Python installed:
1. Download Python 3.11+ from https://www.python.org/downloads/
2. During installation, check "Add Python to PATH"

### Step 2: Install Dependencies
Open PowerShell in this folder and run:
```powershell
pip install -r requirements.txt
```

### Step 3: Connect Scanner
1. Connect your Epson V300 via USB
2. Make sure the Epson driver is installed
3. Turn on the scanner

## Usage

### Start the Application
```powershell
python film_scanner.py
```

### Scanning Process
1. **Configure Settings**
   - Resolution: 2400 DPI recommended for 35mm film
   - Color Mode: Choose color, grayscale, or B&W
   - Output Format: TIFF for highest quality

2. **Preview** (Optional)
   - Click "Preview" to see a low-res preview
   - Adjust film position if needed

3. **Scan**
   - Click "Scan" for a single image
   - Click "Batch Scan" for multiple frames

4. **Files Saved**
   - Default location: Desktop/Scans
   - Files auto-named: film_scan_0001.tif, film_scan_0002.tif, etc.

## Recommended Settings for Film

### 35mm Film (Full Frame)
- **Resolution**: 2400-3200 DPI
- **Color Mode**: Color (or Grayscale for B&W film)
- **Format**: TIFF (uncompressed)

### Medium Format (120 Film)
- **Resolution**: 2400 DPI
- **Color Mode**: Color
- **Format**: TIFF

### Slides
- **Resolution**: 3200-4800 DPI
- **Color Mode**: Color
- **Format**: TIFF

## Troubleshooting

### Scanner Not Detected
- Ensure USB cable is connected
- Restart scanner
- Reinstall Epson driver from epson.com

### Preview/Scan Button Disabled
- TWAIN library not installed
- Run: `pip install pytwain`

### Slow Scanning
- Lower resolution for faster scans
- 2400 DPI is usually sufficient for 35mm film

### Image Quality Issues
- Clean scanner glass before scanning
- Use TIFF format for no compression
- Increase DPI for more detail

## Tips

- Clean your scanner glass and film holder regularly
- Use 2400 DPI for normal prints, 4800+ DPI for enlargements
- TIFF files are large but preserve quality for editing
- Use batch mode to scan entire rolls efficiently

## System Requirements

- Windows 10 or 11
- Python 3.11 or higher
- Epson V300 scanner with driver installed
- 4GB RAM minimum (8GB recommended for high-res scans)

## License

Free to use and modify for personal use.
